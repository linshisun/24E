#ifndef __STOPPER_H
#define __STOPPER_H

void Stopper_Init(void);

#endif
