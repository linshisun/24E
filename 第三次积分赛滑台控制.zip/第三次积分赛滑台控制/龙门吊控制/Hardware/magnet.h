#ifndef __MAGNET_H
#define __MAGNET_H

void Magnet_Init(void);
void Magnet_Catch(void);
void Magnet_Release(void);

#endif
